
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBqzJ8_J8Ki0_OPBBd-WZ2PSTDJNMy7lo0",
  authDomain: "tournament-140a0.firebaseapp.com",
  projectId: "tournament-140a0",
  storageBucket: "tournament-140a0.appspot.com",
  messagingSenderId: "336315244145",
  appId: "1:336315244145:web:167234b7e96b30ba0605d0",
  measurementId: "G-Z6X65YLHLB"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
