
import { Timestamp } from 'firebase/firestore';

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  balance: number;
  referralCode: string;
  referredBy?: string;
  createdAt: Timestamp;
  adsWatchedToday: number;
  lastAdWatched: Timestamp | null;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  amount: number;
  method: 'bKash' | 'Nagad' | 'Rocket' | 'Bank';
  accountInfo: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: Timestamp;
}

export interface LeaderboardUser {
    id: string;
    displayName: string;
    photoURL: string | null;
    balance: number;
}
