
import React from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import WatchAds from './components/WatchAds';
import Withdraw from './components/Withdraw';
import Leaderboard from './components/Leaderboard';
import Referral from './components/Referral';
import BottomNav from './components/BottomNav';
import Spinner from './components/Spinner';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Main />
      </HashRouter>
    </AuthProvider>
  );
};

const Main: React.FC = () => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-900">
        <Spinner />
      </div>
    );
  }
  
  const showBottomNav = user && location.pathname !== '/login';

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      <div className="container mx-auto max-w-md pb-20">
        <Routes>
          <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
          <Route path="/" element={user ? <Dashboard /> : <Navigate to="/login" />} />
          <Route path="/watch" element={user ? <WatchAds /> : <Navigate to="/login" />} />
          <Route path="/withdraw" element={user ? <Withdraw /> : <Navigate to="/login" />} />
          <Route path="/leaderboard" element={user ? <Leaderboard /> : <Navigate to="/login" />} />
          <Route path="/referral" element={user ? <Referral /> : <Navigate to="/login" />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
      {showBottomNav && <BottomNav />}
    </div>
  );
};

export default App;
