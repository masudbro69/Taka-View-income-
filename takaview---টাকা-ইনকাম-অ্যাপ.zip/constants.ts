
export const APP_NAME = "TakaView";
export const MIN_WITHDRAWAL_AMOUNT = 50;
export const AD_REWARD_AMOUNT = 0.25; // ৳0.25 per ad
export const REFERRAL_BONUS = 10; // ৳10 for successful referral
export const ADS_PER_DAY_LIMIT = 20;
export const AD_COOLDOWN_SECONDS = 30; // 30 seconds between ads
