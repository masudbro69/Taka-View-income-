
import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import Header from './Header';
import { useNavigate } from 'react-router-dom';
import { PlayCircle, DollarSign, UserPlus } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { userProfile } = useAuth();
  const navigate = useNavigate();
  const [displayBalance, setDisplayBalance] = useState(0);

  useEffect(() => {
    if (userProfile) {
      const startBalance = displayBalance;
      const endBalance = userProfile.balance;
      if (startBalance === endBalance) return;
      
      const duration = 1000;
      let startTime: number | null = null;

      const animate = (currentTime: number) => {
        if (startTime === null) startTime = currentTime;
        const elapsedTime = currentTime - startTime;
        const progress = Math.min(elapsedTime / duration, 1);
        const newBalance = startBalance + (endBalance - startBalance) * progress;
        setDisplayBalance(newBalance);

        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
           setDisplayBalance(endBalance);
        }
      };

      requestAnimationFrame(animate);
    }
  }, [userProfile?.balance]);

  if (!userProfile) {
    return <div className="p-4 text-center">লোড হচ্ছে...</div>;
  }

  const { displayName, photoURL, balance } = userProfile;

  return (
    <div className="p-4 space-y-6">
      <Header title="ড্যাশবোর্ড" />
      
      <div className="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg">
        <img
          src={photoURL || `https://i.pravatar.cc/150?u=${userProfile.uid}`}
          alt="Profile"
          className="w-16 h-16 rounded-full border-2 border-teal-400"
        />
        <div>
          <p className="text-gray-400">স্বাগতম,</p>
          <h2 className="text-xl font-semibold text-white">{displayName}</h2>
        </div>
      </div>

      <div className="p-6 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-xl shadow-lg text-center">
        <p className="text-lg text-white font-medium">আপনার বর্তমান ব্যালেন্স</p>
        <h3 className="text-5xl font-bold text-white my-2 tracking-tighter">
          ৳ {displayBalance.toFixed(2)}
        </h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-800 p-4 rounded-lg text-center">
            <p className="text-gray-400">আজকের দেখা বিজ্ঞাপন</p>
            <p className="text-2xl font-bold text-teal-300">{userProfile.adsWatchedToday || 0}</p>
        </div>
         <div className="bg-gray-800 p-4 rounded-lg text-center col-span-1 md:col-span-2">
            <p className="text-gray-400">আপনার রেফারেল কোড</p>
            <p className="text-2xl font-bold text-teal-300 tracking-widest">{userProfile.referralCode}</p>
        </div>
      </div>


      <div className="grid grid-cols-3 gap-4 text-center">
        <button onClick={() => navigate('/watch')} className="flex flex-col items-center p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
          <PlayCircle className="w-8 h-8 text-teal-400 mb-2" />
          <span className="font-semibold">বিজ্ঞাপন দেখুন</span>
        </button>
        <button onClick={() => navigate('/withdraw')} className="flex flex-col items-center p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
          <DollarSign className="w-8 h-8 text-green-400 mb-2" />
          <span className="font-semibold">টাকা তুলুন</span>
        </button>
        <button onClick={() => navigate('/referral')} className="flex flex-col items-center p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
          <UserPlus className="w-8 h-8 text-indigo-400 mb-2" />
          <span className="font-semibold">রেফার করুন</span>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
