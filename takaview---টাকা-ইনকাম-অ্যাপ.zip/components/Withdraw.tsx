
import React, { useState, useEffect } from 'react';
import Header from './Header';
import { useAuth } from '../hooks/useAuth';
import { db } from '../services/firebase';
import { collection, addDoc, serverTimestamp, query, where, getDocs, orderBy } from 'firebase/firestore';
import { MIN_WITHDRAWAL_AMOUNT } from '../constants';
import { WithdrawalRequest } from '../types';

const Withdraw: React.FC = () => {
  const { user, userProfile } = useAuth();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Bank'>('bKash');
  const [accountInfo, setAccountInfo] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<WithdrawalRequest[]>([]);

  const fetchHistory = async () => {
      if (!user) return;
      const q = query(collection(db, 'withdrawal_requests'), where('userId', '==', user.uid), orderBy('requestedAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const historyData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as WithdrawalRequest));
      setHistory(historyData);
  };

  useEffect(() => {
    fetchHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!user || !userProfile) {
      setError('ব্যবহারকারী লগইন করা নেই।');
      return;
    }

    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      setError('অনুগ্রহ করে একটি সঠিক পরিমাণ লিখুন।');
      return;
    }
    if (withdrawAmount < MIN_WITHDRAWAL_AMOUNT) {
      setError(`সর্বনিম্ন উত্তোলনের পরিমাণ ৳${MIN_WITHDRAWAL_AMOUNT}।`);
      return;
    }
    if (withdrawAmount > userProfile.balance) {
      setError('আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই।');
      return;
    }
    if (!accountInfo) {
      setError('অনুগ্রহ করে আপনার অ্যাকাউন্ট নম্বর দিন।');
      return;
    }

    setLoading(true);
    try {
      await addDoc(collection(db, 'withdrawal_requests'), {
        userId: user.uid,
        amount: withdrawAmount,
        method,
        accountInfo,
        status: 'pending',
        requestedAt: serverTimestamp(),
      });
      // Note: A Cloud Function should handle deducting the balance after admin approval, not here.
      setSuccess('আপনার উত্তোলনের অনুরোধ সফলভাবে জমা দেওয়া হয়েছে।');
      setAmount('');
      setAccountInfo('');
      await fetchHistory(); // Refresh history
    } catch (e: any) {
      setError('অনুরোধ জমা দেওয়ার সময় একটি ত্রুটি ঘটেছে: ' + e.message);
    } finally {
      setLoading(false);
    }
  };
  
  const getStatusClass = (status: string) => {
    switch(status) {
        case 'pending': return 'bg-yellow-500 text-yellow-900';
        case 'approved': return 'bg-green-500 text-green-900';
        case 'rejected': return 'bg-red-500 text-red-900';
        default: return 'bg-gray-500 text-gray-900';
    }
  };
  
  const getStatusText = (status: string) => {
    switch(status) {
        case 'pending': return 'বিচারাধীন';
        case 'approved': return 'অনুমোদিত';
        case 'rejected': return 'প্রত্যাখ্যাত';
        default: return 'অজানা';
    }
  };

  return (
    <div className="p-4 space-y-6">
      <Header title="টাকা উত্তোলন" />
      
      <div className="bg-gray-800 p-6 rounded-lg">
        <p className="text-gray-400">আপনার বর্তমান ব্যালেন্স</p>
        <p className="text-3xl font-bold text-teal-300">৳{userProfile?.balance.toFixed(2) || '0.00'}</p>
        <p className="text-sm text-gray-500 mt-2">সর্বনিম্ন উত্তোলন: ৳{MIN_WITHDRAWAL_AMOUNT}</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-gray-800 p-6 rounded-lg space-y-4">
        {error && <p className="text-red-400 text-sm bg-red-900/50 p-2 rounded">{error}</p>}
        {success && <p className="text-green-400 text-sm bg-green-900/50 p-2 rounded">{success}</p>}
        
        <div>
          <label className="text-sm font-medium text-gray-300">উত্তোলনের মাধ্যম</label>
          <select value={method} onChange={(e) => setMethod(e.target.value as any)} className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500">
            <option value="bKash">বিকাশ</option>
            <option value="Nagad">নগদ</option>
            <option value="Rocket">রকেট</option>
            <option value="Bank">ব্যাংক ট্রান্সফার</option>
          </select>
        </div>
        <div>
          <label className="text-sm font-medium text-gray-300">অ্যাকাউন্ট নম্বর</label>
          <input type="text" value={accountInfo} onChange={e => setAccountInfo(e.target.value)} placeholder="e.g., 01700000000" className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" />
        </div>
        <div>
          <label className="text-sm font-medium text-gray-300">টাকার পরিমাণ (৳)</label>
          <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder={`${MIN_WITHDRAWAL_AMOUNT}`} className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" />
        </div>
        <button type="submit" disabled={loading || (userProfile?.balance || 0) < MIN_WITHDRAWAL_AMOUNT} className="w-full py-3 font-semibold text-gray-900 bg-teal-400 rounded-md hover:bg-teal-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors">
          {loading ? 'প্রসেস হচ্ছে...' : 'অনুরোধ পাঠান'}
        </button>
      </form>

      <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">উত্তোলনের ইতিহাস</h3>
          <div className="space-y-3 max-h-60 overflow-y-auto">
              {history.length > 0 ? history.map(req => (
                  <div key={req.id} className="flex justify-between items-center bg-gray-700 p-3 rounded-md">
                      <div>
                          <p className="font-semibold text-white">৳{req.amount.toFixed(2)} - {req.method}</p>
                          <p className="text-xs text-gray-400">{new Date(req.requestedAt.toDate()).toLocaleString('bn-BD')}</p>
                      </div>
                      <span className={`px-2 py-1 text-xs font-bold rounded-full ${getStatusClass(req.status)}`}>{getStatusText(req.status)}</span>
                  </div>
              )) : <p className="text-gray-500 text-center">কোনো ইতিহাস নেই।</p>}
          </div>
      </div>
    </div>
  );
};

export default Withdraw;
