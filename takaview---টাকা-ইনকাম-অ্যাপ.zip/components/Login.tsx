import React, { useState } from 'react';
import { GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../services/firebase';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { UserProfile } from '../types';
import { REFERRAL_BONUS } from '../constants';
import Spinner from './Spinner';

const Login: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const generateReferralCode = (length = 8) => {
    return Math.random().toString(36).substring(2, 2 + length).toUpperCase();
  };

  const createUserProfile = async (user: import('firebase/auth').User, referredBy?: string) => {
    const userDocRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
      const newUserProfile: Omit<UserProfile, 'uid'> = {
        email: user.email,
        displayName: displayName || user.displayName || 'TakaView User',
        photoURL: user.photoURL,
        balance: referredBy ? REFERRAL_BONUS : 0,
        referralCode: generateReferralCode(),
        referredBy: referredBy,
        createdAt: serverTimestamp(),
        adsWatchedToday: 0,
        lastAdWatched: null
      };
      await setDoc(userDocRef, newUserProfile);
       // Note: In a real app, a Cloud Function would credit the referrer.
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      await createUserProfile(result.user);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };
  
  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        if (password.length < 6) {
            throw new Error("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
        }
        if(!displayName) {
            throw new Error("অনুগ্রহ করে আপনার নাম দিন।");
        }
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await createUserProfile(userCredential.user, referralCode || undefined);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-sm p-8 space-y-6 bg-gray-800 rounded-lg shadow-lg">
        <h1 className="text-3xl font-bold text-center text-teal-300">TakaView</h1>
        <div className="flex border-b border-gray-600">
          <button onClick={() => setIsLogin(true)} className={`w-1/2 py-3 text-center font-semibold ${isLogin ? 'text-teal-400 border-b-2 border-teal-400' : 'text-gray-400'}`}>লগইন</button>
          <button onClick={() => setIsLogin(false)} className={`w-1/2 py-3 text-center font-semibold ${!isLogin ? 'text-teal-400 border-b-2 border-teal-400' : 'text-gray-400'}`}>সাইন আপ</button>
        </div>

        {error && <p className="text-red-400 text-sm text-center bg-red-900/50 p-2 rounded">{error}</p>}
        
        <form onSubmit={handleEmailAuth} className="space-y-4">
          {!isLogin && (
             <div>
                <label className="text-sm font-medium text-gray-300">আপনার নাম</label>
                <input type="text" value={displayName} onChange={e => setDisplayName(e.target.value)} required className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" />
             </div>
          )}
          <div>
            <label className="text-sm font-medium text-gray-300">ইমেইল</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-300">পাসওয়ার্ড</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" />
          </div>
          {!isLogin && (
            <div>
              <label className="text-sm font-medium text-gray-300">রেফারেল কোড (ঐচ্ছিক)</label>
              <input type="text" value={referralCode} onChange={e => setReferralCode(e.target.value)} className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" />
            </div>
          )}
          <button type="submit" disabled={loading} className="w-full py-2 font-semibold text-gray-900 bg-teal-400 rounded-md hover:bg-teal-500 disabled:bg-teal-800 disabled:cursor-not-allowed transition-colors">
            {loading ? <Spinner /> : (isLogin ? 'লগইন করুন' : 'অ্যাকাউন্ট তৈরি করুন')}
          </button>
        </form>

        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-600"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-gray-800 text-gray-400">অথবা</span>
          </div>
        </div>

        <button onClick={handleGoogleSignIn} disabled={loading} className="w-full flex items-center justify-center py-2 space-x-2 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors">
            <svg className="w-5 h-5" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12s5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24s8.955,20,20,20s20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path><path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path><path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"></path><path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571l6.19,5.238C41.383,36.223,44,30.668,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path></svg>
          <span className="font-semibold text-white">গুগল দিয়ে চালিয়ে যান</span>
        </button>
      </div>
    </div>
  );
};

export default Login;