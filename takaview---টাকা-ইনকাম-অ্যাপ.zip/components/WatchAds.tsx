import React, { useState, useEffect } from 'react';
import Header from './Header';
import { useAuth } from '../hooks/useAuth';
import { db } from '../services/firebase';
import { doc, runTransaction, Timestamp } from 'firebase/firestore';
import { AD_REWARD_AMOUNT, ADS_PER_DAY_LIMIT, AD_COOLDOWN_SECONDS } from '../constants';
import { Play, X } from 'lucide-react';

const WatchAds: React.FC = () => {
  const { user, userProfile } = useAuth();
  const [watchingAd, setWatchingAd] = useState(false);
  const [progress, setProgress] = useState(0);
  const [canClaim, setCanClaim] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [error, setError] = useState('');
  
  const adDuration = 15; // 15 seconds

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (watchingAd && progress < 100) {
      timer = setInterval(() => {
        setProgress(prev => prev + 100 / adDuration);
      }, 1000);
    } else if (progress >= 100 && watchingAd) {
      setCanClaim(true);
    }
    return () => clearInterval(timer);
  }, [watchingAd, progress]);

  useEffect(() => {
    if (cooldown > 0) {
      const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldown]);

  const startAdWatch = () => {
    setError('');
    if (!userProfile || !user) {
      setError("ব্যবহারকারী সনাক্ত করা যায়নি।");
      return;
    }
    
    if (userProfile.adsWatchedToday >= ADS_PER_DAY_LIMIT) {
      setError(`আপনি আজ আপনার দৈনিক ${ADS_PER_DAY_LIMIT} টি বিজ্ঞাপনের সীমা পূর্ণ করেছেন।`);
      return;
    }

    if (userProfile.lastAdWatched) {
        const lastAdTime = userProfile.lastAdWatched.toDate().getTime();
        const now = new Date().getTime();
        const secondsSinceLastAd = (now - lastAdTime) / 1000;
        if (secondsSinceLastAd < AD_COOLDOWN_SECONDS) {
            setError(`পরবর্তী বিজ্ঞাপনের জন্য ${Math.ceil(AD_COOLDOWN_SECONDS - secondsSinceLastAd)} সেকেন্ড অপেক্ষা করুন।`);
            setCooldown(Math.ceil(AD_COOLDOWN_SECONDS - secondsSinceLastAd));
            return;
        }
    }
    
    setProgress(0);
    setCanClaim(false);
    setWatchingAd(true);
  };

  const handleClaimReward = async () => {
    if (!user || !userProfile) return;
    
    const userDocRef = doc(db, 'users', user.uid);
    try {
      await runTransaction(db, async (transaction) => {
        const userDoc = await transaction.get(userDocRef);
        if (!userDoc.exists()) {
          throw new Error("ব্যবহারকারী খুঁজে পাওয়া যায়নি।");
        }
        
        const currentData = userDoc.data() as import('../types').UserProfile;
        
        if (currentData.adsWatchedToday >= ADS_PER_DAY_LIMIT) {
             throw new Error("দৈনিক বিজ্ঞাপনের সীমা পূর্ণ হয়েছে।");
        }

        const newBalance = currentData.balance + AD_REWARD_AMOUNT;
        const newAdsWatched = currentData.adsWatchedToday + 1;
        
        transaction.update(userDocRef, {
          balance: newBalance,
          adsWatchedToday: newAdsWatched,
          lastAdWatched: Timestamp.now()
        });
      });
      setCooldown(AD_COOLDOWN_SECONDS);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setWatchingAd(false);
      setProgress(0);
      setCanClaim(false);
    }
  };

  return (
    <div className="p-4">
      <Header title="বিজ্ঞাপন দেখুন" />
      <div className="mt-6 flex flex-col items-center text-center">
        <div className="w-full max-w-xs p-6 bg-gray-800 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold text-white">দৈনিক বিজ্ঞাপন</h3>
          <p className="text-gray-400 mt-2">একটি বিজ্ঞাপন দেখুন এবং ৳{AD_REWARD_AMOUNT.toFixed(2)} উপার্জন করুন।</p>
          <p className="text-teal-300 mt-1">আজ দেখেছেন: {userProfile?.adsWatchedToday || 0}/{ADS_PER_DAY_LIMIT}</p>
          
          {error && <p className="text-red-400 text-sm mt-4 bg-red-900/50 p-2 rounded">{error}</p>}
          {cooldown > 0 && !error && <p className="text-yellow-400 text-sm mt-4">পরবর্তী বিজ্ঞাপন {cooldown} সেকেন্ড পরে।</p>}
          
          <button
            onClick={startAdWatch}
            disabled={cooldown > 0 || watchingAd || (userProfile?.adsWatchedToday || 0) >= ADS_PER_DAY_LIMIT}
            className="mt-6 w-full flex items-center justify-center py-3 px-4 bg-teal-500 text-white font-bold rounded-lg shadow-md hover:bg-teal-600 transition-transform transform hover:scale-105 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:transform-none"
          >
            <Play className="mr-2" />
            বিজ্ঞাপন দেখুন
          </button>
        </div>
      </div>
      
      {watchingAd && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div className="bg-gray-900 rounded-lg p-6 w-11/12 max-w-sm text-center">
            <div className="flex justify-end">
                <button onClick={() => setWatchingAd(false)} className="text-gray-400 hover:text-white">
                    <X/>
                </button>
            </div>
            <h3 className="text-lg font-bold text-teal-300">বিজ্ঞাপন চলছে...</h3>
            <img src="https://picsum.photos/300/200" alt="ad placeholder" className="my-4 rounded-lg mx-auto" />
            <p className="text-gray-300">অনুগ্রহ করে অপেক্ষা করুন...</p>
            <div className="w-full bg-gray-700 rounded-full h-2.5 mt-4">
              <div className="bg-teal-400 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <button
              onClick={handleClaimReward}
              disabled={!canClaim}
              className="mt-6 w-full py-2 px-4 bg-green-500 text-white font-bold rounded-lg disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              পুরস্কার সংগ্রহ করুন
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default WatchAds;