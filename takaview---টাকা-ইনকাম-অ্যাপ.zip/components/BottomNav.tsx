
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, PlayCircle, DollarSign, BarChart2, UserPlus, LogOut } from 'lucide-react';
import { auth } from '../services/firebase';
import { signOut } from 'firebase/auth';

const BottomNav: React.FC = () => {
  const handleSignOut = () => {
    signOut(auth).catch(error => console.error("Sign out error", error));
  };

  const navItems = [
    { to: '/', icon: Home, label: 'হোম' },
    { to: '/watch', icon: PlayCircle, label: 'বিজ্ঞাপন' },
    { to: '/withdraw', icon: DollarSign, label: 'উইথড্র' },
    { to: '/leaderboard', icon: BarChart2, label: 'লিডারবোর্ড' },
    { to: '/referral', icon: UserPlus, label: 'রেফার' },
  ];

  const activeLinkClass = 'text-teal-400';
  const inactiveLinkClass = 'text-gray-400 hover:text-white';

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 max-w-md mx-auto z-50">
      <div className="flex justify-around items-center h-16">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => `${isActive ? activeLinkClass : inactiveLinkClass} flex flex-col items-center justify-center transition-colors duration-200`}
          >
            <item.icon className="w-6 h-6" />
            <span className="text-xs mt-1">{item.label}</span>
          </NavLink>
        ))}
        <button onClick={handleSignOut} className={`${inactiveLinkClass} flex flex-col items-center justify-center transition-colors duration-200`}>
          <LogOut className="w-6 h-6" />
          <span className="text-xs mt-1">লগআউট</span>
        </button>
      </div>
    </nav>
  );
};

export default BottomNav;
