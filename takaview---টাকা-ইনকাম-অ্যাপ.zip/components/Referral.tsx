
import React, { useState } from 'react';
import Header from './Header';
import { useAuth } from '../hooks/useAuth';
import { REFERRAL_BONUS } from '../constants';
import { Copy, Share2 } from 'lucide-react';

const Referral: React.FC = () => {
  const { userProfile } = useAuth();
  const [copied, setCopied] = useState(false);

  if (!userProfile) {
    return <div className="p-4 text-center">লোড হচ্ছে...</div>;
  }

  const referralCode = userProfile.referralCode;
  const referralLink = `${window.location.origin}/#/login?ref=${referralCode}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'TakaView অ্যাপে যোগ দিন',
        text: `TakaView অ্যাপে যোগ দিন এবং বিজ্ঞাপন দেখে টাকা আয় করুন! আমার রেফারেল কোড ব্যবহার করুন: ${referralCode}`,
        url: referralLink,
      }).catch(console.error);
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(referralLink);
      alert('রেফারেল লিঙ্ক ক্লিপবোর্ডে কপি করা হয়েছে!');
    }
  };

  return (
    <div className="p-4 space-y-8">
      <Header title="বন্ধু রেফার করুন" />

      <div className="text-center bg-gray-800 p-8 rounded-xl shadow-lg">
        <h2 className="text-2xl font-bold text-white">বন্ধুদের আমন্ত্রণ জানান</h2>
        <p className="mt-2 text-gray-400">
          আপনার বন্ধুদের রেফার করুন এবং তারা সাইন আপ করলে আপনি এবং আপনার বন্ধু উভয়েই ৳{REFERRAL_BONUS} বোনাস পাবেন!
        </p>
      </div>

      <div className="text-center">
        <p className="text-gray-400 mb-2">আপনার রেফারেল কোড</p>
        <div className="flex items-center justify-center p-4 bg-gray-700 border-2 border-dashed border-gray-500 rounded-lg">
          <p className="text-3xl font-bold text-teal-300 tracking-widest">{referralCode}</p>
        </div>
        <button
          onClick={handleCopy}
          className="mt-4 inline-flex items-center px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-500 transition-colors"
        >
          <Copy className="mr-2 h-5 w-5" />
          {copied ? 'কপি হয়েছে!' : 'কোড কপি করুন'}
        </button>
      </div>

      <div className="text-center">
        <button
            onClick={handleShare}
            className="w-full max-w-xs mx-auto flex items-center justify-center py-3 px-4 bg-teal-500 text-white font-bold rounded-lg shadow-md hover:bg-teal-600 transition-colors"
        >
            <Share2 className="mr-3" />
            এখনই শেয়ার করুন
        </button>
      </div>
    </div>
  );
};

export default Referral;
