
import React, { useState, useEffect } from 'react';
import Header from './Header';
import { db } from '../services/firebase';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { LeaderboardUser } from '../types';
import Spinner from './Spinner';
import { Award } from 'lucide-react';

const Leaderboard: React.FC = () => {
  const [users, setUsers] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, orderBy('balance', 'desc'), limit(20));
        const querySnapshot = await getDocs(q);
        const leaderboardUsers = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        })) as LeaderboardUser[];
        setUsers(leaderboardUsers);
      } catch (error) {
        console.error("Error fetching leaderboard: ", error);
      } finally {
        setLoading(false);
      }
    };
    fetchLeaderboard();
  }, []);
  
  const getRankColor = (rank: number) => {
      if (rank === 0) return 'text-yellow-400';
      if (rank === 1) return 'text-gray-300';
      if (rank === 2) return 'text-yellow-600';
      return 'text-gray-500';
  }

  return (
    <div className="p-4">
      <Header title="লিডারবোর্ড" />
      {loading ? (
        <div className="flex justify-center mt-20">
          <Spinner />
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {users.map((user, index) => (
            <div key={user.id} className="flex items-center bg-gray-800 p-3 rounded-lg shadow-md">
              <div className={`w-10 text-xl font-bold text-center ${getRankColor(index)}`}>
                  {index < 3 ? <Award size={28} className="mx-auto" fill={getRankColor(index).replace('text-','')} /> : `#${index + 1}`}
              </div>
              <img
                src={user.photoURL || `https://i.pravatar.cc/150?u=${user.id}`}
                alt={user.displayName}
                className="w-12 h-12 rounded-full mx-4 border-2 border-gray-600"
              />
              <div className="flex-grow">
                <p className="font-semibold text-white truncate">{user.displayName}</p>
                <p className="text-sm text-gray-400">মোট আয়</p>
              </div>
              <div className="text-lg font-bold text-teal-300">
                ৳{user.balance.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Leaderboard;
